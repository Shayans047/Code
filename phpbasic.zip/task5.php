<?php
define("Cars",["Civic","toyota","vigo"]);
echo Cars[1];
?>