<?php
$name="Shayan";
echo "My name is ". $name;
?>