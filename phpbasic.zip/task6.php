<?php
$value=20;
$value1=20;
if($value >$value1){
    echo "Greater value is ".$value;
}
elseif($value<$value1){
   print "Smaller value is   ".$value1;
}
else{
 
    echo "Values are equal ";
}
?>