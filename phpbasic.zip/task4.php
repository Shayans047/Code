<?php
$name="Shayan ";
echo "The string is : ".$name;
echo "<br>";
echo" Length of String is :". strlen($name);
echo "<br>";
echo"Reverse String is : ".strrev($name);
echo "<br>";
echo "After replacing :".str_replace($name,"Shehroz",$name);
echo"<br>";
?>