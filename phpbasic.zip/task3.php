<?php
$num1=15;
$num2=10;
$sum=0;
$sum=$num1+$num2;
echo "the sum of two numbers is : $sum";
$sum=$num1-$num2;
echo "<br>";
echo "The sub of two numbers is : $sum";
?>