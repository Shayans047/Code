import java.util.*;
public class primenumber {
    public static void main(String[]arr){
        Scanner s=new Scanner(System.in);
        System.out.println("enter the number to check :");
        int n=s.nextInt();
        boolean is_prime=true;
        if (n == 0 || n == 1) {
            is_prime = false;
        }
        for (int i = 2; i <= n/2; ++i) {
            if (n % i == 0)
            {
               is_prime = false;
                break;
            }
        }
        if (is_prime){
            System.out.println("your number is prime :"+n);
        }
        else {
            System.out.println("your number is not prime :"+n);
        }


    }
}
