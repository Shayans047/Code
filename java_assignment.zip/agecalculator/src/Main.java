import java.util.*;
public class Main {
    public static void main(String[] args) {
        int date,month,born_year,current_year,age,days,weeks,months,leap_year;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter your birth date :");
        date= sc.nextInt();
        System.out.println("enter your birthday month :");
        month=sc.nextInt();
        System.out.println("enter your birth year :");
        born_year= sc.nextInt();
        System.out.println("your date of birth is : "+date+" / "+month+" / "+born_year);
        System.out.println("enter current year :");
        current_year=sc.nextInt();
        age=current_year-born_year;

        System.out.println("your age is : "+age);
        days=age*365;
        System.out.println("days in your age is : "+days);
        months=age*12;
        System.out.println("months in your age is :"+months);
        weeks=age*(12*4);
        System.out.println("weeks in your age is :  "+weeks);
        int count=0;
        while(born_year!=current_year){
            if (((born_year % 4 == 0) && (born_year % 100 != 0)) || (born_year % 400 == 0)){
                count++;
            }
            born_year++;
        }
        System.out.println("lepa year in your age is :  "+count);
    }
}