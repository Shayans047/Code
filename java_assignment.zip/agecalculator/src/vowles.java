import java.util.*;
public class vowles {
    public static  void  main(String[]arr){
        Scanner s=new Scanner(System.in);
        System.out.println("enter the string :");
        String sc=s.nextLine();
        boolean a=true,b=false;
        for(int i=0; i<sc.length(); i++) {
            if(sc.charAt(i) == 'a'|| sc.charAt(i) == 'e'||
                    sc.charAt(i) == 'i' || sc.charAt(i) == 'o' ||
                    sc.charAt(i) == 'u'){
                System.out.println(a);
            }
            else{
                System.out.println(b);
            }

        }
    }
}
