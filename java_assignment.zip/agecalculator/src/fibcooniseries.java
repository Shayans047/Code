import java.util.*;
public class fibcooniseries {
    public  static void main(String[]arr){
        int n=0, t1 = 0, t2 = 1, nextTerm = 0;
Scanner s=new Scanner(System.in);
        System.out.println("Enter the number of terms: ");
        n=s.nextInt();

        System.out.println("Fibonacci Series: ");

        for (int i = 1; i < n; i++) {

            if(i == 1)
            {
                System.out.print(t1+",");
            }
            else if(i == 2)
            {
                System.out.print(t2+",");
                continue;
            }
            nextTerm = t1 + t2;
            t1 = t2;
            t2 = nextTerm;

            System.out.print(nextTerm+",");
        }
    }
}
